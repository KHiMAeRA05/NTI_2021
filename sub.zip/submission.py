#submission
import numpy as np
import sys
import pandas as pd
import pickle
import ast
from catboost import CatBoostClassifier, CatBoostRegressor

np.set_printoptions(threshold=sys.maxsize)


class Predictor():
    def __init__(self):
        with open("model.pkl", "rb") as f:
            self.cat = pickle.load(f)

    def forecast(self, series):
        data = pd.DataFrame(series)

        #обработка данных!!!! колонки должны быть одинаковые с верхними
        val_col = ['Coolness_RHEED', 'Filtered Rate', 'Source Power', 'Length', 'R FWHM_RHEED']
        data = data[val_col]
        data = data.fillna(data.median(axis=0), axis=0)

        data['Cool'] = data['Coolness_RHEED']
        Cool = data['Coolness_RHEED']
        Cool = Cool.shift(periods=-435)
        data['Coolness_RHEED'] = Cool
        data = data[:len(data)-435]

        #предсказание
        return self.cat.predict_proba(data)[-1][1]